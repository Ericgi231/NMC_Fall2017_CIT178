USE AP;

INSERT into TestUniqueNulls 
VALUES (NULL);

INSERT into TestUniqueNulls 
VALUES (NULL);

INSERT into TestUniqueNulls 
VALUES ('Anne Boehm');

INSERT into TestUniqueNulls 
VALUES ('Anne Boehm');