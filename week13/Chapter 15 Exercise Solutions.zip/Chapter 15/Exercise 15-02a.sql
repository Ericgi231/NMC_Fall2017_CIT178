USE AP;

EXEC spBalanceRange 'M%';