USE AP;

UPDATE Invoices
SET PaymentTotal = 67.92, PaymentDate = '2012-04-23'
WHERE InvoiceID = 100;