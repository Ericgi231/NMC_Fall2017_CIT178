USE AP;

EXEC spBalanceRange '[C,F]%', 0, 200;
