ALTER ROLE PaymentEntry DROP MEMBER AAaron;
ALTER ROLE PaymentEntry DROP MEMBER BBrown;
ALTER ROLE PaymentEntry DROP MEMBER CChaplin;
ALTER ROLE PaymentEntry DROP MEMBER DDyer;
ALTER ROLE PaymentEntry DROP MEMBER EEbbers;
ALTER ROLE PaymentEntry DROP MEMBER FFalk;
DROP ROLE PaymentEntry;
